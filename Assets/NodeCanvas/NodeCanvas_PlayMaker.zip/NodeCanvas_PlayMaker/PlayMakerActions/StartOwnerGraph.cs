﻿using UnityEngine;
using System.Collections;
using HutongGames.PlayMaker;
using NodeCanvas;

[ActionCategory("NodeCanvas")]
[Tooltip("Execute a graph already assigned to an owner")]
public class StartOwnerGraph : PlayMakerActions {

	[HutongGames.PlayMaker.RequiredField]
	[Tooltip("The GraphOwner to execute")]
	public GraphOwner graphOwner;
	
	[Tooltip("If true, this FSM Variables will be copied to the blackboard")]
	public bool syncVariables;

	[Tooltip("Possible only if 'Run Forever' is set to false")]
	public FsmEvent finishEvent;

	[UIHint(UIHint.Description)]
	public string desc = "Will start an Owner Graph. Sync Variables will sync supported PlayMaker Variables with Owner's Blackboard variables.";

	public override void Reset(){
		graphOwner = null;
		syncVariables = true;
	}

	public override void OnEnter(){

		if (syncVariables && graphOwner.blackboard != null)
			SyncToNC(graphOwner.blackboard);

		graphOwner.StartGraph(OnGraphFinished);
	}

	public override void OnUpdate(){
		
		if (syncVariables && graphOwner != null)
			SyncToPlayMaker(graphOwner.blackboard);
	}

	private void OnGraphFinished(){

		Finish();
		Fsm.Event(finishEvent);
	}

	public override void OnExit(){

		graphOwner.StopGraph();
		if (syncVariables && graphOwner.blackboard != null)
			SyncToPlayMaker(graphOwner.blackboard);
	}
}