﻿using UnityEngine;
using System.Collections;
using HutongGames.PlayMaker;
using NodeCanvas.DialogueTrees;

[ActionCategory("NodeCanvas")]
[Tooltip("Starts a NodeCanvas Dialogue Tree")]
public class StartDialogueTree : PlayMakerActions {

	[HutongGames.PlayMaker.RequiredField]
	[Tooltip("The Dialogue Tree to start")]
	public DialogueTree dialogueTree;

	[Tooltip("If true, this FSM Variables will be copied to the blackboard")]
	public bool syncVariables = true;

	[Tooltip("Possible only if 'Run Forever' is set to false")]
	public FsmEvent finishEvent;

	public override void Reset(){
		dialogueTree = null;
		syncVariables = true;
	}

	public override void OnEnter(){

		if (dialogueTree == null){
			Finish();
			return;
		}

		if (syncVariables && dialogueTree.blackboard != null)
			SyncToNC(dialogueTree.blackboard);

		dialogueTree.StartGraph(OnGraphFinished);
	}

	public override void OnUpdate(){
		
		if (syncVariables && dialogueTree.blackboard != null)
			SyncToPlayMaker(dialogueTree.blackboard);
	}

	private void OnGraphFinished(){

		Finish();
		Fsm.Event(finishEvent);
	}

	public override void OnExit(){

		dialogueTree.StopGraph();
		if (syncVariables && dialogueTree.blackboard != null)
			SyncToPlayMaker(dialogueTree.blackboard);
	}
}
