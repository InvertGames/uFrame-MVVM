﻿#if UNITY_EDITOR
using UnityEditor;
#endif

using UnityEngine;
using System.Collections.Generic;
using HutongGames.PlayMaker;

namespace NodeCanvas.Actions{

	[ScriptCategory("PlayMaker")]
	public class SendPlayMakerEvent : ActionTask {

		[RequiredField]
		public PlayMakerFSM playmakerFSM;
		[RequiredField]
		public string eventName;

		protected override string info{
			get
			{
				if (playmakerFSM == null)
					return "No PlayMakerFSM Selected";
				return "Send Event '" + eventName + "' PlayMaker";
			}
		}

		protected override void OnExecute(){

			playmakerFSM.SendEvent(eventName);
			EndAction(true);
		}

		////////////////////////////////////////
		///////////GUI AND EDITOR STUFF/////////
		////////////////////////////////////////
		#if UNITY_EDITOR
		
		protected override void OnTaskInspectorGUI(){

			playmakerFSM = EditorGUILayout.ObjectField("PlayMakerFSM", playmakerFSM, typeof(PlayMakerFSM), true) as PlayMakerFSM;

			if (playmakerFSM == null){
				return;
			}

			FsmTransition[] globalTransition = playmakerFSM.FsmGlobalTransitions;
			List<string> eventNames = new List<string>();
			foreach(FsmTransition transition in globalTransition)
				eventNames.Add(transition.EventName);

			eventName = EditorUtils.StringPopup("Global Transition Event", eventName, eventNames);
		}
		
		#endif
	}
}